package com.dominio.conexion;

import java.io.IOException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

/**
 * Servlet implementation class ControladorDino
 */
@WebServlet("/ControladorDino")
public class ControladorDino extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ModeloDinosaur modeloDinosaur; // llamamos a class ModeloDinosaur - INSTANCIA -

	@Resource(name = "jdbc/dinosaur")
	private DataSource miPool;

	@Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		super.init();
		try {
			modeloDinosaur = new ModeloDinosaur(miPool);
		} catch (Exception e) {
			throw new ServletException(e);
		}

	} // END init
	
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// así controlamos segun lo que se pulse - se recarga solo al insertar
		String comando = request.getParameter("instruccion"); // en comando guardamos valor instruccion de cada JSP
		if (comando == null) comando = "listar";
		switch (comando) {
		case "listar":
			obtenerDino(request, response);
			break;
		case "insetarBBDD":
			try {
				insertarDino(request, response);
			} catch (Exception e) {
				// e.printStackTrace();
				// Aquí puedes agregar tu mensaje personalizado
				System.out.println("Ha ocurrido un error: " + e.getMessage());
			}
			break;
		case "cargar":
			try {
				cargarDino(request, response);
			} catch (Exception e) {
				// e.printStackTrace();
				// Aquí puedes agregar tu mensaje personalizado
				System.out.println("Ha ocurrido un error: " + e.getMessage());
			}
			break;
		case "actualizarBBDD":
			try {
				actualizarNuevoDino(request, response);
			} catch (Exception e) {
				System.out.println("Ha ocurrido un error: " + e.getMessage());
			}
			break;
		case "eliminar":
			try {
				eliminarDino(request, response);
			} catch (Exception e) {
				System.out.println("Ha ocurrido un error: " + e.getMessage());
			}
			break;
		default:
			obtenerDino(request, response);
		}		
	} // END doGet

	
	private void eliminarDino(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String nameDino = request.getParameter("name"); 
		modeloDinosaur.eliminarBBDD(nameDino); // nos manda a ModeloDinosaur.java
		obtenerDino(request, response);
	}

	
	private void actualizarNuevoDino(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// coge parametro modificado en formularioActualizar.jsp

		String nameDino = request.getParameter("nameA"); 
		String periodDino = request.getParameter("periodA"); 
		String dietDino = request.getParameter("dietA"); 
		String countryDino = request.getParameter("countryA"); 
		// creamos el core
		Dinosaur modificaDino = new Dinosaur (nameDino, periodDino, dietDino, countryDino);
		modeloDinosaur.actualizaDinoBBDD(modificaDino); // metodo en class ModeloDinosaur

		// para que se nos liste llamamos metodo obtenerDino
		obtenerDino(request, response);
		// Redirige a la misma página o a otra página después de la inserción - para que no repita insercion
	   // response.sendRedirect("ControladorDino?instruccion=listar");  
	}

	// modifica listaDinosaur.jsp boton q le pusimos update
	private void cargarDino(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// leer datos del name
		String name = request.getParameter("name");
		//comunicar con modelo para enviarle el name y que este nos devuelva datos Dino actualizado
		Dinosaur dinoCargar = modeloDinosaur.getDinoCargar(name); // se crea en ModeloDinosaur
		//establecer atributo
		request.setAttribute("nameCargar",dinoCargar);
		// enviar el name del Dino al modelo
		RequestDispatcher dispatcher = request.getRequestDispatcher("formularioActualizar.jsp");
		dispatcher.forward(request, response);
		// Redirige a la misma página o a otra página después de la inserción - para que no repita insercion
	    //response.sendRedirect("ControladorDino?instruccion=listar");
	}

	private void insertarDino(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException  { //inserta formularioInsertar.jsp
		String name = request.getParameter("name"); //cogemos datos del jsp con getParameter
		String period = request.getParameter("period");
		String diet = request.getParameter("diet");
		String country = request.getParameter("country");
		
		// objeto del contocutor con todos los campos
		Dinosaur nuevoDino = new Dinosaur (name,period,diet,country); //llegan datos formulario
		modeloDinosaur.insertarNuevoDino(nuevoDino); //metodo en ModeloDinosaru.java
		obtenerDino(request, response); // para que carge este metodo tras insertar	
		
		// Redirige a la misma página o a otra página después de la inserción - para que no repita insercion
	    response.sendRedirect("ControladorDino?instruccion=listar");
	} // END insertarDino

	private void obtenerDino(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException { // mostrar listaDinosaur.jsp
		//obtener y creamos lista dinosaurios 
		List<Dinosaur> dinosaur;

		try {
			dinosaur = modeloDinosaur.getDinosaur();
			// Añadimos esa lista de dinosaurios al request
			request.setAttribute("listaDinosaur", dinosaur);
			// enviar el request a la pagina jsp(aún no está creada)
			RequestDispatcher miDispatcher = request.getRequestDispatcher("listaDinosaur.jsp");
			miDispatcher.forward(request, response);

		} catch (Exception e) {
			// Aquí puedes agregar tu mensaje personalizado
			System.out.println("Ha ocurrido un error: " + e.getMessage());
			// e.printStackTrace();
		}
		
	} // end obtenerDino

} // END class ControladorDino
