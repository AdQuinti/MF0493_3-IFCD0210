package com.dominio.conexion;

public class Dinosaur {
	private String Name;
	private String Period;
	private String Diet;
	private String Country;

	public Dinosaur(String name, String period, String diet, String country) {
		this.Name = name;
		this.Period = period;
		this.Diet = diet;
		this.Country = country;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		this.Name = name;
	}

	public String getPeriod() {
		return Period;
	}

	public void setPeriod(String period) {
		this.Period = period;
	}

	public String getDiet() {
		return Diet;
	}

	public void setDiet(String diet) {
		this.Diet = diet;
	}

	public String getCountry() {
		return Country;
	}

	public void setCountry(String country) {
		this.Country = country;
	}

	@Override
	public String toString() {
		return "Dinosaur [Name= " + Name + ", Period= " + Period + ", Diet= " + Diet + ", Country= " + Country
				+ "]<br><br>";
	}
}
