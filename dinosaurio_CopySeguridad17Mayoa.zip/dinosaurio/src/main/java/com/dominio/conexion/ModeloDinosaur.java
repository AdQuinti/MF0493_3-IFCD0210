package com.dominio.conexion;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

public class ModeloDinosaur {
	private DataSource origenDatos;

	public ModeloDinosaur(DataSource origenDatos) { // Constructor variable pool conexiones
		this.origenDatos = origenDatos;
	} // END Constructor

	// metodo para devolver una lista de actores
	public List<Dinosaur> getDinosaur() throws Exception {
		List<Dinosaur> Dinosaurios = new ArrayList<>();
		Connection miconexion = null;
		Statement miStatement = null;
		ResultSet miResulset = null;

		// estableceer la conexión
		miconexion = origenDatos.getConnection();
		// crear sentencia SQL y Statement
		String instruccionSql = "SELECT * FROM dinosaur";
		miStatement = miconexion.createStatement();
		// ejecutar SQL
		miResulset = miStatement.executeQuery(instruccionSql);
		// recorrer el iResulset obetnido
		while (miResulset.next()) { // cogemos todas columnas
			String name = miResulset.getString("Name");
			String period = miResulset.getString("Period");
			String diet = miResulset.getString("Diet");
			String country = miResulset.getString("Country");
			// añadimos estos datos a la lista en cada vuelta de bucle
			Dinosaur tempDino = new Dinosaur(name, period, diet, country);
			// añadimos objeto a la lsita
			Dinosaurios.add(tempDino);
		}
		return Dinosaurios;
	} // END getDinosaur

	public void insertarNuevoDino(Dinosaur nuevoDino) { // viene del ControladorDino.java
		// establecer conexion
		Connection miconexion = null;
		// para insertar o modificar dato en BBDD
		PreparedStatement statement = null;
		try {
			miconexion = origenDatos.getConnection();
			//crear instruccion para que inserte datos en BBDD
			String sql = "INSERT INTO dinosaur (name,period,diet,country) VALUE(?,?,?,?);";
			statement = miconexion.prepareStatement(sql);
			// estable parametro para insertar datos en BBDD
			statement.setString(1, nuevoDino.getName());
			statement.setString(2, nuevoDino.getPeriod());
			statement.setString(3, nuevoDino.getDiet());
			statement.setString(4, nuevoDino.getCountry());
			statement.executeUpdate();//inserccion datos
			
		} catch (Exception e) {
			// Aquí puedes agregar tu mensaje personalizado
			System.out.println("insertarNuevoDino - Ha ocurrido un error: " + e.getMessage());
			// e.printStackTrace();
		}finally {
	        if (miconexion!= null) {
	            try {
	                miconexion.close();
	            } catch (SQLException ex) {
	                System.out.println("insertarNuevoDino - Error al cerrar la conexión: " + ex.getMessage());
	            }
	        }
	        if (statement!= null) {
	            try {
	                statement.close();
	            } catch (SQLException ex) {
	                System.out.println("insertarNuevoDino - Error al cerrar el statement: " + ex.getMessage());
	            }
	        }
		}
	} // END insertarNuevoDino

	public Dinosaur getDinoCargar(String name) throws Exception {
		Dinosaur dinoBuscar = null;
		//creamos objetos para establecer conexion
		Connection miconexion = null;
		// para insertar o modificar dato en BBDD
		PreparedStatement statement = null;
		ResultSet resulset = null;
		try {
			// establecemos conexion
			miconexion = origenDatos.getConnection();
			// preparamos SQL
			String sql = "SELECT * FROM dinosaur WHERE Name=?";
			statement = miconexion.prepareStatement(sql);
			statement.setString(1, name);
			resulset = statement.executeQuery();
			
			// comprobacion datos y carga
			if (resulset.next()) {
				String name2 = resulset.getString("name");
				// cogemos datos
				String nameDino = resulset.getString("name"); 
				String periodDino = resulset.getString("period"); 
				String dieteDino = resulset.getString("diet"); 
				String countryDino = resulset.getString("country");
				dinoBuscar = new Dinosaur (nameDino, periodDino, dieteDino, countryDino);
			} else {
				throw new Exception("getDinoCargar - No hemos encontado Dinosaur pedido: "+name);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dinoBuscar;
	} // END getDinoCargar

	public void actualizaDinoBBDD(Dinosaur modificaDino) { // UPDATE viene de controladorDino.java
		// establecer conexion
		Connection miconexion = null;
		// para insertar o modificar dato en BBDD
		PreparedStatement statement = null;
		try {
			miconexion = origenDatos.getConnection();
		    String sql = "UPDATE dinosaur SET period=?,diet=?,country=? WHERE name=?";
		    statement = miconexion.prepareStatement(sql);
		    statement.setString(1, modificaDino.getName());
		    statement.setString(2, modificaDino.getPeriod());
		    statement.setString(3, modificaDino.getDiet());
		    statement.setString(4, modificaDino.getCountry());
			statement.execute();//inserccion datos
		
			} catch (Exception e) {
				// Aquí puedes agregar tu mensaje personalizado
				System.out.println("actualizaDinoBBDD - Ha ocurrido un error: " + e.getMessage());
				// e.printStackTrace();
			}	finally {
		        if (miconexion!= null) {
		            try {
		                miconexion.close();
		            } catch (SQLException ex) {
		                System.out.println("actualizaDinoBBDD - Error cerrar conexión: " + ex.getMessage());
		            }
		        }
		        if (statement!= null) {
		            try {
		                statement.close();
		            } catch (SQLException ex) {
		                System.out.println("actualizaDinoBBDD - Error cerrar statement: " + ex.getMessage());
		            }
		        }
		    }
	} // end actualizaDinoBBDD

	public void eliminarBBDD(String nameDino) {
		// establecer conexion
		Connection miconexion = null;
		// para insertar o modificar dato en BBDD
		PreparedStatement statement = null;
		 try {
			miconexion = origenDatos.getConnection();
			String sql = "DELETE FROM dinosaur WHERE name=?";
			statement = miconexion.prepareStatement(sql);
		    statement.setString(1, nameDino);
			statement.executeUpdate();//inserccion datos
			
		} catch (SQLException e) {
			System.out.println("eliminarBBDD - Ha ocurrido error: " + e.getMessage());
		}	finally {
	        if (miconexion!= null) {
	            try {
	                miconexion.close();
	            } catch (SQLException ex) {
	                System.out.println("eliminarBBDD - Error cerrar conexión: " + ex.getMessage());
	            }
	        }
	        if (statement!= null) {
	            try {
	                statement.close();
	            } catch (SQLException ex) {
	                System.out.println("eliminarBBDD - Error cerrar statement: " + ex.getMessage());
	            }
	        }
	    }
	}

} // END class ModeloDinosaur
