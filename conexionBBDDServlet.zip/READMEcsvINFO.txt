 - INSTRUCCIONES INSTALACION -
En Workbench crear una BBDD con nombre ACTORES_SAKILA.
Con esta sentencia "CREATE DATABASE ACTORES_SAKILA;"
Luego en la opcion table dentro de esta BBDD creada le
damos a boton derecho y opcion "Tabla Data Import Wizard",
buscamos csv de actor.csv e importamos (siguiente todo el rato).
Ya se estaría añadida y se puede trabajar con ella.