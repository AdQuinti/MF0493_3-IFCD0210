package com.dominio.conexion;

import java.io.IOException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

/**
 * Servlet implementation class ControladorActor
 */
@WebServlet("/ControladorActor")
public class ControladorActor extends HttpServlet {
	private static final long serialVersionUID = 1L;
	//creamos una variable del tipo modelo actor
	private ModeloActor modeloActor;
	
	@Resource(name="jdbc/actor")
	private DataSource miPool;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	
	@Override
	public void init(ServletConfig config) throws ServletException {
	    super.init(config);
	    try {
	        modeloActor = new ModeloActor(miPool);
	    } catch (Exception e) {
	        throw new ServletException(e);
	    }
	    System.out.println("init");
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException,
	IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		//obtenemos la lista de actores desde el modelo
		
		
		String comando = request.getParameter("instruccion");
				if (comando == null) comando = "listar";
		switch (comando) {
		case "listar":
			obtenerActor(request, response);
			break;
		case "insertarBBDD":
			insertarActor(request,response);
			break;
			
		case "cargar":
			try {
				cargarActor(request,response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("ERROR: "+ e.getMessage());
			}
			break;
			
		case "actualizarBBDD":
			try {
				actualizarNuevoActor(request,response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println(e.getMessage());
			}
			break;
	
		case "eliminar":
			try {
				eliminarActor(request,response);
				}catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		System.out.println(e.getMessage());
				}
			break;
			default: obtenerActor(request,response);
			}}
		
	private void eliminarActor(HttpServletRequest request, HttpServletResponse response) throws Exception {
	    int idActor = Integer.parseInt(request.getParameter("id_Actor"));
	   
	    modeloActor.eliminarBBDD(idActor);
	    obtenerActor(request, response);
	}
			

	

	private void actualizarNuevoActor(HttpServletRequest request, HttpServletResponse response) throws Exception{
		// TODO Auto-generated method stub
		int idActor = Integer.parseInt(request.getParameter("idActor"));
		String nombreActor =request.getParameter("nombreA");
		String apellidoActor = request.getParameter("ApellidoA");
		String fecha = request.getParameter("Actualizacion");
		
		Actor nuevoActor = new Actor (idActor,nombreActor, apellidoActor,fecha);
		modeloActor.actualizarActorBBDD(nuevoActor);
		obtenerActor(request,response);
		
	}

	private void cargarActor(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		//leer datos del id del actor
		int idActor = Integer.parseInt(request.getParameter("id_Actor"));
		//comunicar con el modelo para enviarle el id y que este nos devuelva el actor
		Actor actorCargar = modeloActor.getActorCargar(idActor);
		//establecer el atributo
		request.setAttribute("id_actorCargar", actorCargar);
		//enviar el id al modelo
		RequestDispatcher dispatcher = request.getRequestDispatcher("/formularioActualizar.jsp");
		dispatcher.forward(request, response);
		
	}

	private void insertarActor(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		int idActor = Integer.parseInt(request.getParameter("idActor"));
		String nombreActor = request.getParameter("nombreA");
		String apellidoActor= request.getParameter("ApellidoA");
		String actualizacion= request.getParameter("Actualizacion");
		
		Actor actores= new Actor (idActor, nombreActor,apellidoActor,actualizacion);
		modeloActor.insertarNuevoActor(actores);
		obtenerActor(request,response);
		System.out.println("insertarActor");
		
	}

	private void obtenerActor(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		List<Actor>actores;
		try {
			actores = modeloActor.getActor();
			//añadimos la lista de actores al request
			request.setAttribute("ListaActores", actores);
			//enviar el request a la pagina jsp(aun no creada)
			RequestDispatcher miDispatcher = request.getRequestDispatcher("/ListaActores.jsp");
			miDispatcher.forward(request, response);
			
			}catch(Exception e){
				e.printStackTrace();
				System.out.println("ERROR: " + e.getMessage());
			}
		
	}
				
           }

	


