package com.dominio.conexion;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

public class ModeloActor {
	private DataSource origenDatos;
	
	public ModeloActor (DataSource origenDatos) {
		this.origenDatos = origenDatos;
	}
	
	//método para devolver una lista de actores
	public List<Actor>getActor()throws Exception {
		List<Actor>actores = new ArrayList<>();
		Connection miConexion = null;
		Statement miStatement = null;
		ResultSet miResultSet = null;
		//establecer la conexion
		miConexion = origenDatos.getConnection();
		//crear sentencia sql
		String instruccionSql = "SELECT*FROM actorhollywood";
		miStatement = miConexion.createStatement();
		//ejecutar sql
		miResultSet = miStatement.executeQuery(instruccionSql);
		//recorrer el miResultset obtenido
		while (miResultSet.next()) {
			int idActor = miResultSet.getInt("actor_id");
			String nombreActor = miResultSet.getString("first_name");
			String apellidoActor = miResultSet.getString("last_name");
			String actualizacion = miResultSet.getString("last_update");
			//añadimos estos datos a la lista en cada vuelta de bucle
			Actor tempActor = new Actor (idActor, nombreActor, apellidoActor,actualizacion);
			//añadimos el objeto a la lista
			actores.add(tempActor);
		}
		return actores;
	}

	public void insertarNuevoActor(Actor actores) {
		// TODO Auto-generated method stub
		//establecer la conexion
		Connection conexion = null;
		PreparedStatement statement = null;
			try {
				conexion= origenDatos.getConnection();
				//creamos instruccion sql
				String sql="INSERT INTO actorHollywood (actor_id, first_name, last_name, "
						+ "last_update) VALUES(?,?,?,?)";
				
				statement = conexion.prepareStatement(sql);
				
				//establecer los parametros para insertar el actor insert into
				statement.setInt(1,actores.getActor_id());
				statement.setString(2,actores.getFirst_name());
				statement.setString(3,actores.getLast_name());
				statement.setString(4,actores.getLast_update());
				//ejecutamos el sql
				statement.execute();
				
				
			}catch(Exception e) {
				System.out.println("ERROR: "+ e.getMessage());
			}
			
			
			
	}

	 public Actor getActorCargar(int idActor) throws Exception{
			// TODO Auto-generated method stub
			//creamos un objeto de la clase actor para guardar los datos del registro
			Actor actorBuscar = null;
			Connection conexion = null;
			PreparedStatement statement = null;
			ResultSet resultset = null;
			//establecemos la conexion
			try {
				conexion = origenDatos.getConnection();
			//crear la sentencia sql
			String sql="SELECT*FROM actorHollywood WHERE actor_id=?";
			statement = conexion.prepareStatement(sql);
			statement.setInt(1,idActor);
			resultset = statement.executeQuery();
			
			if (resultset.next()) {
				int id_Actor = resultset.getInt("actor_id");
				String nombreActor = resultset.getString("first_name");
				String apellidoActor = resultset.getString("last_name");
				String actualizacion = resultset.getString("last_update");
				actorBuscar = new Actor(id_Actor,nombreActor,apellidoActor,actualizacion);
			}else {
				throw new Exception("NO se ha encontrado el actor con el id: "+ idActor);
				
			}
			
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return actorBuscar;
		}

	public void actualizarActorBBDD(Actor nuevoActor) {
		// TODO Auto-generated method stub
		Connection conexion = null;
		PreparedStatement statement = null;
		//establecemos conexion
		try {
			conexion = origenDatos.getConnection();
			String sql = "UPDATE actorhollywood SET first_name=?, last_name=?, last_update=? WHERE actor_id=? ";
		//crear consulta preparada
			statement = conexion.prepareStatement(sql);
			statement.setString (1, nuevoActor.getFirst_name());
			statement.setString (2, nuevoActor.getLast_name());
			statement.setString (3, nuevoActor.getLast_update());
			statement.setInt (4, nuevoActor.getActor_id());
			
			statement.execute();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		
	}

	public void eliminarBBDD(int idActor) {
		// TODO Auto-generated method stub
		Connection conexion = null;
		PreparedStatement statement = null;
		
		
		try {
		conexion= origenDatos.getConnection();
		String sql = "DELETE FROM actorhollywood WHERE actor_id=?";
		statement = conexion.prepareStatement(sql);
		statement.setInt(1, idActor);
		statement.execute();
		
		}catch (SQLException e) {
		// TODO Auto-generated method stub
			e.printStackTrace();
		}
	} 

	}