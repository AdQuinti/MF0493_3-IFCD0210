package com.dominio.conexion;
/**
 * @project petroleospain
 * @autor AdQuinti on 18/05/2024
 * 
 * MVC Controlador
 * BBDD petroleo2024spain
 */
import java.io.IOException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

/**
 * Servlet implementation class ControladorPetrol
 */
@WebServlet("/ControladorPetrol")
public class ControladorPetrol extends HttpServlet {
	private static final long serialVersionUID = 1L;
	//creamos una variable del tipo MODELO
	private ModeloPetrol modeloPetrol;
	
	@Resource(name="jdbc/petrol") // linea de context.xml
	private DataSource miPool;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	public void init(ServletConfig config) throws ServletException {
	    super.init(config);
	    try {
	    	modeloPetrol = new ModeloPetrol(miPool);
	    } catch (Exception e) {
	        //throw new ServletException(e);
	        System.out.println("ERROR en init: " + e.getMessage());
	    }
//System.out.println("paso por init");
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//obtenemos la lista de actores desde el modelo
		String comando = request.getParameter("instruccion");
		if (comando == null) comando = "listado";
		switch (comando) {
			case "listado":
				obtenerPetrol(request, response); // muestra listado.jsp
				break;
				
			case "insertarBBDD":
				insertarPetrol(request,response);
				break;
				
			case "cargar":
				try {
					cargarPetrol(request,response);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					System.out.println("ERROR: "+ e.getMessage());
				}
				break;
				
			case "actualizarBBDD":
				try {
					actualizarNuevoPetrol(request,response);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					System.out.println(e.getMessage());
				}
				break;
		
			case "eliminar":
				try {
					eliminarPetrol(request,response);
					}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
					}
				break;
				default: obtenerPetrol(request,response); // carga metodo listarPetrol.jsp
		} // END SWITCH-CASE
	} // END doGet
	
	
// METODOS conexion y accion a pag.web
	
	private void eliminarPetrol(HttpServletRequest request, HttpServletResponse response) throws Exception {
	    int idPetrol = Integer.parseInt(request.getParameter("id_Petrol"));
	   // llamamos al metodo en ModeloPetrol
	    modeloPetrol.eliminarBBDD(idPetrol);
	    obtenerPetrol(request, response);
	} // END eliminarPetrol
	
	private void actualizarNuevoPetrol(HttpServletRequest request, HttpServletResponse response) throws Exception{
		// forma parte de formularioActualizar.jsp
		int idPetrolActualizar = Integer.parseInt(request.getParameter("idPetrol"));
		String fechaActualizar =request.getParameter("fechaA");
		String comunidadActualizar = request.getParameter("comunidadA");
		String provinciaActualizar = request.getParameter("provinciaA");
		String productoActualizar = request.getParameter("productoA");
		int consumoActualizar = Integer.parseInt(request.getParameter("consumoA"));
		// guardamos datos actualizados en variable que será mandada a ModeloPetrol
		VistaPetrol nuevoPetrol = new VistaPetrol (idPetrolActualizar,fechaActualizar, comunidadActualizar,provinciaActualizar,productoActualizar,consumoActualizar);
		modeloPetrol.actualizarPetrolBBDD(nuevoPetrol);
		obtenerPetrol(request,response);
	} // END actualizarNuevoPetrol

	private void cargarPetrol(HttpServletRequest request, HttpServletResponse response) throws Exception {
		//forma parte de formularioActualizar.jsp
		//leer datos del id del actor
		int idPetrolCargar = Integer.parseInt(request.getParameter("id_Petrol"));
		//comunicar con el modelo para enviarle el id y que este nos devuelva el actor
		VistaPetrol petrolCargar = modeloPetrol.getPetrolCargar(idPetrolCargar);
		//establecer el atributo
		request.setAttribute("id_petrolCargar", petrolCargar);
		//enviar el id al modelo
		RequestDispatcher dispatcher = request.getRequestDispatcher("/formularioActualizar.jsp");
		dispatcher.forward(request, response);
	} // END cargarPetrol

	private void insertarPetrol(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		// metodo que inserta datos con formularioInsertar.jsp
		int idPetrolInsertar = Integer.parseInt(request.getParameter("idPetrol"));
		String fechaInsertar = request.getParameter("fechaA");
		String comunidadInsertar= request.getParameter("comunidadA");
		String provinciaInsertar= request.getParameter("provinciaA");
		String productoInsertar= request.getParameter("productoA");
		int consumoInsertar= Integer.parseInt(request.getParameter("consumoA"));
		
		VistaPetrol petroleo= new VistaPetrol (idPetrolInsertar,fechaInsertar,comunidadInsertar,provinciaInsertar,productoInsertar,consumoInsertar);
		modeloPetrol.insertarNuevoPetrol(petroleo);
		obtenerPetrol(request,response);
	} // END insertarPetrol

	private void obtenerPetrol(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Muestra listaPetro.jsp
		List<VistaPetrol>petroleo;
		try {
			petroleo = modeloPetrol.getPetrol(); // metodo en Modelo.java
			//añadimos la lista de actores al request
			request.setAttribute("listaPetrol", petroleo); // etiqueta items en listaPetrol.jsp
			//enviar el request a la pagina lista.jsp
			RequestDispatcher miDispatcher = request.getRequestDispatcher("/listaPetrol.jsp");
			miDispatcher.forward(request, response);
			}catch(Exception e){
				e.printStackTrace();
				System.out.println("ERROR mostrar lista.jsp: " + e.getMessage());
			} 
	} // END obtenerPetrol

} // END ControladorPetrol
