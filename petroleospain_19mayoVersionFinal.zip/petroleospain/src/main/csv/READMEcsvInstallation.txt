 - INSTRUCCIONES INSTALACION -
En Workbench crear una BBDD con nombre PETROLEO2024PROVINCIA
Con esta sentencia "CREATE DATABASE PETROLEO2024PROVINCIA;"
Luego en la opcion table dentro de esta BBDD creada le
damos a boton derecho y opcion "Tabla Data Import Wizard",
buscamos csv de actor.csv e importamos (siguiente todo el rato).
Ya se estaría añadida y se puede trabajar con ella.

Programas necesarios: XAMPP para apache y MySQL (donde estará la
BBDD). Y el WorkBench para realizar los pasos previos para su
creación e importación de tablas.